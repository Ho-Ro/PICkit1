/*
 Test out pic14 .hex file reading and writing, by 
 using the reader and writer to copy a .hex.
*/
#include <stdlib.h>
#include "pic14.h"

int main(int argc,char *argv[]) {
	if (argc!=3) {
		printf("usage: test_pic_hex <in file> <out file>\n"); exit(1);
	}
	else {
		FILE *src=fopen(argv[1],"r");
		FILE *dest=fopen(argv[2],"w");
		pic14_state p;
		const char *err;
		err=pic14_hex_read(&p,src);
		if (err) {fprintf(stderr,"Fatal error reading hex file %s> %s\n",argv[1],err);return 0;}
		pic14_hex_write(&p,dest);
	}
	return 0;
}

