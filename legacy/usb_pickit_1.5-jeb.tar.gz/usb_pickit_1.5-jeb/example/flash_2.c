/*****************************************************************************
Tiny demo program to light the LEDs on the PICkit.         

Orion Sky Lawlor, olawlor@acm.org, 2003/8/4 (public domain)
*/
#include "pickit.h"

__IDLOC(1);
__CONFIG(INTIO & WDTDIS & MCLRDIS & BORDIS & UNPROTECT & PWRTEN);

void main()
{
	clear();
	
	while(1)
	{	
		byte state;
		for (state=0;state<2;state++) {
			led(state+3); 
			busywait(250);
		}
	}
}

