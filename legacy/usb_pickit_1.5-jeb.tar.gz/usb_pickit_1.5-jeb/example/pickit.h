/*
Little utility routines for running the 
Microchip(tm) PICkit(tm) FLASH Starter Kit
USB device programmer.

Orion Sky Lawlor, olawlor@acm.org, 2003/8/4 (public domain)
*/
#ifndef __OSL_PIC_PICKIT_H
#define __OSL_PIC_PICKIT_H

#include <pic.h>

typedef unsigned char byte;

// Light this LED, numbered from 0..7
void led(byte led)             
{
	/* These tables come from the wiring on the 
	   PICkit's LEDs.  We tristate all but two pins,
	   and either forward or reverse bias the two 
	   non-tristated pins.  This drives exactly one
	   LED on the display.
	 */
	const static byte trsTable[8]={
		0b11001111,
		0b11001111,
		0b11101011,
		0b11101011,
		0b11011011,
		0b11011011,
		0b11111001,
		0b11111001
	};
	const static byte gpTable[8]={
		0b00010000,
		0b00100000,
		0b00010000,
		0b00000100,
		0b00100000,
		0b00000100,
		0b00000100,
		0b00000010
	};
	TRISIO = trsTable[led];
	GPIO = gpTable[led];
}


// Busywait for this long (FIXME: should use sleep & timer)
void busywait(byte ms) {
	for (;ms!=0;ms--) 
	{ // Wait for one millisecond (depends on compiler, optimizer)
		byte c;
		for (c=250;c!=0;c--) {}
	}
}

// Turn all hardware off (e.g., at startup)
void clear(void) {
	TRISIO = 0xFF;
	GPIO = 0; 
	VRCON = 0; 
	CMCON = 0x07;
	TMR0 = 0;
	OPTION = 0x80;
	ANSEL = 0x31;
	ADCON0 = 0x01;
	T0IE = 0;
	ADIE = 0;
	GIE = 0;
	T0IF = 0;
	ADIF = 0;
	GPIF = 0;
}

#endif
