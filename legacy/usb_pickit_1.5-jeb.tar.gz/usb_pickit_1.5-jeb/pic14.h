/**
Header file to describe the programmable state
of the 14-bit instruction word Microchip PIC microcontrollers, 
such as the pic12F675 or the pic16F676.

Orion Sky Lawlor, olawlor@acm.org, 2003/8/3
*/
#ifndef __OSL_PIC14_H
#define __OSL_PIC14_H

#include <stdio.h>

/** One storage location in the EEPROM has this type: */
typedef unsigned char pic14_ee;

/** One instruction has this type: (but only low 14 bits are used) 
*/
typedef unsigned short pic14_inst;

/** One data or program memory reference has this type:
*/
typedef unsigned short pic14_word;

/** A (program) address has this type:
*/
typedef unsigned int pic14_addr;

/** Program state for pic14-series microcontroller */
typedef struct {
// JEB - Changed from 0x0fff to 0x01fff to go up to 8K for newer devices
#define pic14_inst_len 0x01fffu /* up to 8192 words of program */
	/**
	  Regular program memory runs from 0x0000 to 0x0fff.
	*/
        pic14_addr inst_len;
	pic14_word inst[pic14_inst_len];
        pic14_addr max_prog;
	/* JEB - Computed checksum from memory buffer stored here*/
	pic14_word instchecksum;
	
#define pic14_ee_len 256u /* 256 bytes of EEPROM */
	/**
	  EEPROM data is available at offsets 0 - 127 or 255.
	  Only the low 8 bits are actually stored.
	*/
        pic14_addr ee_len;
	pic14_word ee[pic14_ee_len];
        pic14_addr max_ee;
} pic14_program;

/** Hard configuration state for pic14 microprocessor */
typedef struct {
	/**
	  Oscilator calibration word, stored at 0x3ff.
	*/
	pic14_word osccal;
	
#define pic14_id_len 4u
	/**
	  Special configuration memory "User ID" words, at
	  configuration address 0x2000 - 0x2003.
	  Supposedly, only the low 7 bits are usable.
	*/
	pic14_word id[pic14_id_len];
	
	/**
	  Special configuration word, at 0x2007.
	*/
	pic14_word config;

        /* Save OSCCAL, or not? */
        unsigned char save_osccal;

	/* JEB - Config word mask value for computing checksum */
	pic14_word configmask;

	/* JEB - Read pgm checksum from "S" command stored here
	must be and'ed with masked config value*/
	pic14_word pgmchecksum;
	/* JEB - EE Data checksum stored here*/
	unsigned char eechecksum;	
} pic14_config;

/** All programmable state on a pic14 */
typedef struct {
	pic14_program program;
	pic14_config config;
} pic14_state;

/** Initialize this state to a reasonable power-up value.*/
void pic14_state_init(pic14_state *p);


/** Describes an address range that can be treated uniformly */
typedef struct {
	pic14_addr addr;  /* First word address */
	pic14_addr len;   /* Number of word addresses */
	pic14_word *data; /* Actual data (in a pic14_program) */
	const char *desc; /* Human-readable description */
} pic14_span;
#define pic14_program_nspans 5
/** Extract a list of spans from this program. */
void pic14_program_spans(pic14_state *p,pic14_span destspans[]);

/** Read this program from a .hex file. Returns NULL on 
   success, or an error message on error.
*/
const char *pic14_hex_read(pic14_state *p,FILE *src);

/** Write this program to a .hex file */
void pic14_hex_write(pic14_state *p,FILE *dest);

#endif
