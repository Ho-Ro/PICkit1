/*
 Main program-- command-line argument handling and top-level control.
*/
#include <stdlib.h>
#include <string.h>
#include "usb_pickit.h"

/* Write .hex file data into a chip */
const char *programMode(usb_pickit *d,const char *inFile,int keepOld) {
	FILE *f=fopen(inFile,"r");
	pic14_state p;
	const char *err;
	if (f==NULL) return "could not find program file";
	// Zero out the state first, so anything that isn't read
	//  won't be uninitialized.	
	pic14_state_init(&p);
	err=usb_pickit_get_device(d,&p);
	if (err!=NULL) return err;
	err=pic14_hex_read(&p,f);
	if (err!=NULL) return err;
	fclose(f);
	usb_pickit_write(d,&p,keepOld);
	return NULL;
}

/* Read chip data into a .hex file */
const char *extractMode(usb_pickit *d,const char *outFile) {
	FILE *f=fopen(outFile,"w");
	const char *err;
	pic14_state p;
	if (f==NULL) return "could not create output file";
	err=usb_pickit_get_device(d,&p);
	if (err!=NULL) return err;
	usb_pickit_read(d,&p);
	// JEB added calc checksum function
	usb_pickit_calc_checksum(&p);
	pic14_hex_write(&p,f);
	fclose(f);
	return NULL;
}

/* JEB - Verify the contents of the device with a .hex file*/
const char *verifyMode(usb_pickit *d,const char *inFile) {
	FILE *f=fopen(inFile,"r");
	pic14_state pfile, pdev;
	const char *err;
	if (f==NULL) return "could not find program file";
	// Zero out the state first, so anything that isn't read
	//  won't be uninitialized.	
	pic14_state_init(&pfile);
	err=usb_pickit_get_device(d,&pfile);
	if (err!=NULL) return err;
	err=pic14_hex_read(&pfile,f);
	if (err!=NULL) return err;
	fclose(f);
	usb_pickit_calc_checksum(&pfile);
	pdev.config.configmask = pfile.config.configmask;
	pdev.program.inst_len = pfile.program.inst_len;
	pdev.program.ee_len = pfile.program.ee_len;
	usb_pickit_read(d,&pdev);
	usb_pickit_calc_checksum(&pdev);
	usb_pickit_verify(&pfile, &pdev);
	return NULL;
}

/* JEB - Check to make sure chip is blank*/
const char *blankcheckMode(usb_pickit *d) {
        const char *err;
        pic14_state p;
        err=usb_pickit_get_device(d,&p);
        if (err!=NULL) return err;
        usb_pickit_read(d,&p);
        usb_pickit_calc_checksum(&p);
	usb_pickit_blank_check(&p);
        return NULL;
}

/* JEB - Regnerate OscCal, for 629,675,630 and 676 only*/
const char *osccalregenMode(usb_pickit *d) {
	FILE *f=fopen("autocal.hex","r");
	pic14_state p;
	const char *err;
	if (f==NULL) return "could not find the autocal.hex file";
	// Zero out the state first, so anything that isn't read
	//  won't be uninitialized.	
	pic14_state_init(&p);
	err=usb_pickit_get_device(d,&p);
	if (err!=NULL) return err;
	if (p.config.save_osccal) {
		err=pic14_hex_read(&p,f);
		if (err!=NULL) return err;
		fclose(f);
		usb_pickit_write(d,&p,1);
		/* JEB- For some reason, have to close the USB device and reopen to get the OscCal regen
		to work.   This function is not used all that often, so it's not worth trying to
		figure out why this is so.   It works as is, but just prints the Device found info
		twice because of the multiple open calls.*/
		usb_close(d);
 		usb_pickit *d2=usb_pickit_open();
		usb_pickit_osccal_regen(d2,&p);
	} else
                printf("Only PIC 629,675,630,676 support OscCal Regeneration.\n");
	return NULL;
}

void printUsage(const char *why) {
	printf(
		" Microchip(tm) PICkit(tm) 1 USB Programmer controller program\n"
		"\n"
		"Usage: one of\n"
		" usb_pickit <file>  (Writes .hex file to chip)\n"
		" usb_pickit --program <file> (Verbose version of above)\n"
		" usb_pickit --extract <file> (Read from chip into .hex file)\n"
		" usb_pickit --verify  <file> (Read from chip and compare with .hex file)\n"
		" usb_pickit --blankcheck (Read chip, check all locations for 1 or blank)\n"
		" usb_pickit --erase (Erase device.   Preserve OscCal and BG Bits if implemented)\n"
		" usb_pickit --bandgap <bg> (Erase device.  Preserve OscCal and write specified BG Bits)\n"
		" usb_pickit --osccalregen (Erase device.  Regenerate OscCal using autocal.hex)\n"
		" usb_pickit --memorymap (Show device Program and EE Data Memory)\n"
		" usb_pickit --config (Show configuration data)\n"
		" usb_pickit --reset (Power cycle the chip)\n"
 		" usb_pickit --off   (Turn chip power off)\n"
 		" usb_pickit --on    (Turn chip power back on)\n"
		" usb_pickit --oscoff   (Turn 2.5 hHz osc off, leave chip on)\n"
                " usb_pickit --oscon    (Turn 2.5 kHz osc on, with chip on)\n"
		" usb_pickit --programall <file> (Overwrite OscCal and BG (!))\n"
		" usb_pickit --help (This message)\n"
		"   <file> is an Intel MDS .hex file\n"
 		" Version 1.5, Jeff Boly, jboly@teammojo.org, 2005/12/25\n"
		" Other contributions by Mark Rages, markrages@gmail.com, 2005/4/1\n"
 		" Original Code, Orion Sky Lawlor, olawlor@acm.org, 2004/1/19\n"
		" Exiting: %s\n",why); 
	exit(1);
}

/* JEB - added code here for osc on and off flags, and also added Mark Rages
get_device subroutine to the config option so that we can see and use it there as well.
Added the state &p to the print checksum routine to get device info */
int main(int argc,char *argv[]) {
	const char *err=NULL;
	const char *arg;
	pic14_state p;
	if (argc<2) printUsage("no mode argument given");
	arg=argv[1];
	if (0==strcmp(arg,"--program")) {
		if (argc!=3) printUsage("program mode argument error");
 		usb_pickit *d=usb_pickit_open();
		err=programMode(d,argv[2],1);
	} else if (0==strcmp(arg,"--programall")) {
		if (argc!=3) printUsage("program mode argument error");
 		usb_pickit *d=usb_pickit_open();
		err=programMode(d,argv[2],0);
	} else if (0==strcmp(arg,"--extract")) {
		if (argc!=3) printUsage("extract mode argument error");
 		usb_pickit *d=usb_pickit_open();
		err=extractMode(d,argv[2]);
	} else if (0==strcmp(arg,"--verify")) {
		if (argc!=3) printUsage("verify mode argument error");
 		usb_pickit *d=usb_pickit_open();
		err=verifyMode(d,argv[2]);
	} else if (0==strcmp(arg,"--blankcheck")) {
 		usb_pickit *d=usb_pickit_open();
		err=blankcheckMode(d);
	} else if (0==strcmp(arg,"--erase")) {
		usb_pickit *d=usb_pickit_open();
		err=usb_pickit_get_device(d,&p);
		usb_pickit_erase(d,&p);
	} else if (0==strcmp(arg,"--bandgap")) {
		if (argc!=3) printUsage("bandgap mode argument error");
 		usb_pickit *d=usb_pickit_open();
		err=usb_pickit_get_device(d,&p);
		usb_pickit_bandgap(d,&p,argv[2]);
	} else if (0==strcmp(arg,"--osccalregen")) {
 		usb_pickit *d=usb_pickit_open();
		err=osccalregenMode(d);
	} else if (0==strcmp(arg,"--memorymap")) {
		usb_pickit *d=usb_pickit_open();
		err=usb_pickit_get_device(d,&p);
		usb_pickit_read(d,&p);
		usb_pickit_memory_map(d,&p);
	} else if (0==strcmp(arg,"--config")) {
		usb_pickit *d=usb_pickit_open();
		err=usb_pickit_get_device(d,&p);
		usb_pickit_print_config(d,&p);
 	} else if (0==strcmp(arg,"--off")) {
 		usb_pickit *d=usb_pickit_open();
 		usb_pickit_off(d);
 	} else if (0==strcmp(arg,"--on")) {
 		usb_pickit *d=usb_pickit_open();
 		usb_pickit_on(d);
	} else if (0==strcmp(arg,"--oscoff")) {
 		usb_pickit *d=usb_pickit_open();
                usb_pickit_osc_off(d);
        } else if (0==strcmp(arg,"--oscon")) {
 		usb_pickit *d=usb_pickit_open();
                usb_pickit_osc_on(d);
	} else if (0==strcmp(arg,"--reset")) {
 		usb_pickit *d=usb_pickit_open();
		usb_pickit_off(d);
		usb_pickit_on(d);
	} else if (0==strcmp(arg,"--help") || 0==strcmp(arg,"-h")) {
		printUsage("command line usage");
	} 
	else if (arg[0]=='-') {
		printUsage("unrecognized mode argument");
	}
	else /* non-flag argument-- treat as file */ {
		usb_pickit *d=usb_pickit_open();
		err=programMode(d,arg,1);
	}
	
	if (err) {fprintf(stderr,"Fatal error> %s\n",err);return 0;}
	return 0;
}

