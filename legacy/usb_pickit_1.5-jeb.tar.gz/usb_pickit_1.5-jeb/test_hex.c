/*
 Test out .hex file reading and writing, by 
 using the reader and writer to copy a .hex.
*/
#include <stdlib.h>
#include "hex.h"

int main(int argc,char *argv[]) {
	if (argc!=3) {
		printf("usage: test_hex <in file> <out file>\n"); exit(1);
	}
	else {
		FILE *src=fopen(argv[1],"r");
		FILE *dest=fopen(argv[2],"w");
		const char *err;
		hex_write_begin(dest);
		err=hex_read(src, (hex_dest_fn)hex_write, dest);
		if (err) {fprintf(stderr,"Fatal error reading hex file %s> %s\n",argv[1],err);return 0;}
		hex_write_end(dest);
	}
	return 0;
}

