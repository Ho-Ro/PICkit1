/**
A USB interface to the Microchip(tm) PICkit(tm) 1 FLASH Starter Kit
device programmer and breadboard.

Orion Sky Lawlor, olawlor@acm.org, 2003/8/3
*/
#ifndef __OSL_USB_PICKIT_H
#define __OSL_USB_PICKIT_H

#include "pic14.h"

typedef struct usb_dev_handle usb_pickit;

/** Generic abort routine */
void bad(const char *why);

/** Open the pickit as a usb device.  Aborts on errors. */
usb_pickit *usb_pickit_open(void);

/** Turn the device on */
void usb_pickit_on(usb_pickit *d);

/** Turn the device off */
void usb_pickit_off(usb_pickit *d);

/** Turn the 2.5 kHz osc on */
void usb_pickit_osc_on(usb_pickit *d);

/** Turn the 2.5 kHz osc off */
void usb_pickit_osc_off(usb_pickit *d);

/** Read device type */
const char *usb_pickit_get_device(usb_pickit *d, pic14_state *s);

/** JEB - Generate Checksum from what was read into memory */
void usb_pickit_calc_checksum(pic14_state *s);

/** JEB - Read Checksum direct from programmer using "S" function */
void usb_pickit_read_checksum(usb_pickit *d,pic14_state *s);

/** Fill out this program with the current contents of the device. 
 */
void usb_pickit_read_program(usb_pickit *d,pic14_program *p);

/** Fill out this configuration with the contents of the device. 
 */
void usb_pickit_read_config(usb_pickit *d,pic14_config *c);

/** Fill out this state with the contents of the device. 
 */
void usb_pickit_read(usb_pickit *d,pic14_state *s);

/** Write this state.  If keepOld (RECOMMENDED), will 
   preserve old osccal and BG bits. */
void usb_pickit_write(usb_pickit *d,pic14_state *s,int keepOld);

/* JEB - Erase device.   Preserve OSCCAL and BG bits if needed*/
void usb_pickit_erase(usb_pickit *d,pic14_state *s);

/** Do a hard chip reset. You *must* preserve config first. 
    This clears both program and config, you must then
    call write_program and merge_config (or write_config).
*/
void usb_pickit_reset(usb_pickit *d, int keepEeprom);

/** Send this program to the device (requires reset first).
 */
void usb_pickit_write_program(usb_pickit *d,pic14_program *p);

/** Send off this configuration (requires reset first).
    Copies osccal, ID, and BG bits from oldconfig, everything 
    else from newconfig. (these are the preserved bits)
 */
void usb_pickit_merge_config(usb_pickit *d,
	pic14_config *oldconfig, pic14_config *newconfig);

/** JEB - Set bandgap bits.   For 629,675,630 and 676 only.   */
void usb_pickit_bandgap(usb_pickit *d,pic14_state *s,const char *bgarg);

/** JEB - Regenerate OscCal using autocal.hex file.   For 629,675,630 and 676 only.   */
void usb_pickit_osccal_regen(usb_pickit *d,pic14_state *s);

/** Send off this config.  WARNING: do not reset osccal and BG bits!  */
void usb_pickit_write_config(usb_pickit *d,pic14_config *c);

/** Print the device memory map, display all program and data memory values. */
void usb_pickit_memory_map(usb_pickit *d,pic14_state *s);

/** Print the whole configuration set (osccal, id, and config word). */
/** JEB -- added state as function input to enhance config output */
void usb_pickit_print_config(usb_pickit *d,pic14_state *s);

/* JEB -  .hex file to device verify operation. */
void usb_pickit_verify(pic14_state *file, pic14_state *dev); 

/* JEB - device blank check.*/
void usb_pickit_blank_check(pic14_state *s);

#endif
