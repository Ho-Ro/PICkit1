/**
A USB interface to the Microchip PICkit 1 FLASH Starter Kit
device programmer and breadboard.

Orion Sky Lawlor, olawlor@acm.org, 2003/8/3
Mark Rages, markrages@gmail.com, 2005/4/1
Jeff Boly, jboly@teammojo.org, 2005/12/31
  See README for changelog.
*/
#include <usb.h> /* libusb header */
#include <unistd.h> /* for geteuid */
#include "usb_pickit.h"

/* PICkit USB values */
const static int pickit_vendorID=0x04d8; // Microchip, Inc
const static int pickit_productID=0x0032; // PICkit 1 FLASH starter kit
const static int pickit_configuration=2; /* 1: HID; 2: vendor specific */
const static int pickit_interface=0;
const static int pickit_endpoint=1; /* first endpoint for everything */
const static int pickit_timeout=1000; /* timeout in ms */

/* PICkit always uses 8-byte transfers */
const static int reqLen=8;
typedef unsigned char byte;

void bad(const char *why) {
	fprintf(stderr,"Fatal error> %s\n",why);
	exit(17);
}

/* Stupidity:
  In an excellent example of sacrificing backward compatability
for conformance to some proported "standard", the latest Linux 
kernel USB drivers (uhci-alternate in 2.4.24+, and uhci in 2.6.x)
no longer support low speed bulk mode transfers-- they give
"invalid argument", errno=-22, on any attempt to do a low speed 
bulk write.  Thus, we need interrupt mode transfers, which are 
only available via the CVS version of libusb.

(Thanks to Steven Michalske for diagnosing the true problem here.)
*/
/* JEB - Note here, for the Mac, there is no interrupt mode, so need to set this
 define to zero to get it to compile.   I use Mac OS X.
*/
#ifndef HAVE_LIBUSB_INTERRUPT_MODE 
 #define HAVE_LIBUSB_INTERRUPT_MODE 0 
#endif

#if HAVE_LIBUSB_INTERRUPT_MODE
/* latest libusb: interrupt mode, works with all kernels */
 #define PICKIT_USB(direction) usb_interrupt_##direction
#else 
/* older libusb: bulk mode, will only work with older kernels */
 #define PICKIT_USB(direction) usb_bulk_##direction
#endif

/****************** Internal I/O Commands *****************/

/** Send this binary string command. */
static void send_usb(usb_pickit *d,const char *src) {
  
	int r=PICKIT_USB(write)(d,pickit_endpoint,
		(char *)src,reqLen,pickit_timeout);
	if (r!=reqLen) { perror("usb PICkit write"); bad("USB write failed"); }
}

/** Write the next program counter with this word.
    Uses "W" command.
*/
static void send_usb_word(usb_pickit *d,pic14_word w) {
	char cmd[reqLen];
	sprintf(cmd,"W__ZZZZZ");
	cmd[1]=(char)(w&0xff);
	cmd[2]=(char)((w>>8)&0xff);
	send_usb(d,cmd);
}
/** Write the next n program counters with these words. */
/** JEB - I like the way that MAR added the '.' that print out during the write, nice touch. */
static void send_usb_words(usb_pickit *d,unsigned int n,pic14_word *w) {
	unsigned int i;
	for (i=0;i<n;i++) {
	  fprintf(stderr,"."); // MAR add
	  send_usb_word(d,w[i]); 
	}
	fprintf(stderr,"\n"); // MAR add
}

/** Read this many bytes from this device */
/* JEB - added (char *) casting to dest to supress the signedness difference warning, during compilation */
static void recv_usb(usb_pickit *d,int len,byte *dest) {
  int i;

	int r=PICKIT_USB(read)(d,pickit_endpoint,(char *)dest,len,pickit_timeout);
	if (r!=len) { perror("usb PICkit read"); bad("USB read failed"); }

}

/** Read 4 words from the current address */
static void recv_usb_words4(usb_pickit *d,pic14_word *dest) {
	int i;
	byte recv[reqLen];
	send_usb(d,"RZZZZZZZ");
	recv_usb(d,reqLen,recv);
	for (i=0;i<4;i++) dest[i]=recv[2*i+0]+(recv[2*i+1]<<8);
}

/** Read this many words from the device */
static void recv_usb_words(usb_pickit *d,unsigned int len,pic14_word *dest) {
	while (len>0) {
		pic14_word recv[4];
		unsigned int i, c=4; /* # of words to copy out */
		recv_usb_words4(d,recv);
		if (c>len) c=len;
		for (i=0;i<c;i++) { dest[i]=recv[i];
		//printf("d=0x%04x l=0x%04x c=x%1x  \n",dest[i],len,c);
		}
		dest+=c; len-=c;
	}
}

/* debugging: enable debugging error messages in libusb */
extern int usb_debug;

/* Find the first USB device with this vendor and product.
   Exits on errors, like if the device couldn't be found.
*/
usb_pickit *usb_pickit_open(void)
{
  struct usb_device *device;
  struct usb_bus* bus;

  if (geteuid()!=0)
    bad("This program must be run as root, or made setuid root");
  
#ifdef USB_DEBUG
  usb_debug=4; 
#endif
  printf("Locating USB Microchip(tm) PICkit(tm) (vendor 0x%04x/product 0x%04x)\n",
  	pickit_vendorID,pickit_productID);
  /* (libusb setup code stolen from John Fremlin's cool "usb-robot") */
  usb_init();
  usb_find_busses();
  usb_find_devices();
  
  for (bus=usb_busses;bus!=NULL;bus=bus->next) 
  {
    struct usb_device* usb_devices = bus->devices;
    for(device=usb_devices;device!=NULL;device=device->next)
    {
      if (device->descriptor.idVendor == pickit_vendorID
        &&device->descriptor.idProduct == pickit_productID)
      {
	  usb_dev_handle *d;
	  printf( "Found USB PICkit as device '%s' on USB bus %s\n",
 		   device->filename,
		   device->bus->dirname);
          d=usb_open(device);
	  if (d)
	  { /* This is our device-- claim it */
	      byte retData[reqLen];
	      if (usb_set_configuration(d,pickit_configuration)) {
	          bad("Error setting USB configuration.\n");
	      }
	      if (usb_claim_interface(d,pickit_interface)) {
	          bad("Claim failed-- the USB PICkit is in use by another driver.\n"
		  	"Do a `dmesg` to see which kernel driver has claimed it--\n"
			"You may need to `rmmod hid` or patch your kernel's hid driver.\n");
	      }
	     /* Turn off power to the chip before doing anything.
	         This prevents weird random errors during programming.
	         ( Thanks to Curtis Sell for this fix. )
	      */
	      usb_pickit_off(d);
	      send_usb(d,"vZZZZZZZ");
	      recv_usb(d,reqLen,retData);
	      printf("Communication established.  Onboard firmware version is %d.%d.%d\n",
		  	(int)retData[0],(int)retData[1],(int)retData[2]);
	      if (retData[0]>0x02u)
	          printf("Warning: USB PICkit major version is %d; last known working version is 2\n",(int)retData[0]);
	      return d;
	  }
          else 
	      bad("Open failed for USB device");
      }
      /* else some other vendor's device-- keep looking... */
    }
  }
  bad("Could not find USB PICkit device--\n"
      "you might try lsusb to see if it's actually there.");
  return NULL;
}

/** Turn the device on */
void usb_pickit_on(usb_pickit *d) {
	send_usb(d,"V1ZZZZZZ");
}

/** Turn the device off */
void usb_pickit_off(usb_pickit *d) {
	send_usb(d,"V0ZZZZZZ");
}

/* JEB - Here added support for turning the 2.5kHz osc on an off for calibration */
/** Turn the 2.5 kHz osc on */
void usb_pickit_osc_on(usb_pickit *d) {
        send_usb(d,"V3ZZZZZZ");
}       
 
/** Turn the 2.5 kHz osc off */
void usb_pickit_osc_off(usb_pickit *d) { 
        send_usb(d,"V1ZZZZZZ");
}

/** Get device ID */
/* JEB fixed bug here where programming mode is ended using the 'p'
but the device power was not turned back on.   This is important
as it is the only way to reset the device after enter/exiting the VPP high
programming mode. Also added config word mask for each device for computing
checksum also added 1 to the inst_len field that Mark Rages created.    There 
seems to be a bug when reading from the PICkit.   Not sure where, but the end
result is that the last byte read is corrupted if the read does not fall on
a four byte boundary. So I simply increased the size of the program memory read by 1.
this bug only seems to effect the 627,675,630,676 devices.*/
const char *usb_pickit_get_device(usb_pickit *d, pic14_state *s) {
        char *deviceName;
	char *err=NULL;
        int rev;
        pic14_word id_word;
        send_usb(d,"pV0V1PCZ");
	/* Read id. word from 0x2006 */
	send_usb(d,"pPCI\x06\x00ZZ");
	recv_usb_words(d,1,&id_word);
	send_usb(d,"pV1ZZZZZ");
	
	/* fprintf(stderr,"Device ID 0x%x\n",id_word);*/
	rev=id_word&0x1f;
	switch (id_word&0xffe0) {
	case 0x0f80:
	  deviceName="12F629";
	  s->program.inst_len=0x03ff;
	  s->program.ee_len=128;
	  s->config.save_osccal=1;
	  s->config.configmask=0x1ff;
	  break;
	case 0x0fc0:
	  deviceName="12F675";
	  s->program.inst_len=0x03ff;
	  s->program.ee_len=128;
	  s->config.save_osccal=1;
	  s->config.configmask=0x1ff;
	  break;	  
	case 0x10c0:
	  deviceName="16F630";
	  s->program.inst_len=0x03ff;
	  s->program.ee_len=128;
	  s->config.save_osccal=1;
	  s->config.configmask=0x1ff;
	  break;	  
	case 0x10e0:
	  deviceName="16F676";
	  s->program.inst_len=0x03ff;
	  s->program.ee_len=128;
	  s->config.save_osccal=1;
	  s->config.configmask=0x1ff;
	  break;	  
	  /////////////////////////////
	case 0x0fa0:
	  deviceName="16F635";
	  s->program.inst_len=0x0400;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0x1fff;
	  break;	  
	case 0x0460:
	  deviceName="16F683";
	  s->program.inst_len=0x0800;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0xfff;
	  break;	  
	case 0x10a0:
	  deviceName="16F636 / 16F639";
	  s->program.inst_len=0x0800;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0x1fff;
	  break;	  
	case 0x1080:
	  deviceName="16F684";
	  s->program.inst_len=0x0800;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0xfff;
	  break;	  
	case 0x04a0:
	  deviceName="16F685";
	  s->program.inst_len=0x1000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0xfff;
	  break;	  
	case 0x1320:
	  deviceName="16F687";
	  s->program.inst_len=0x0800;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0xfff;
	  break;	  
	case 0x1180:
	  deviceName="16F688";
	  s->program.inst_len=0x1000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0xfff;
	  break;	  
	case 0x1340:
	  deviceName="16F689";
	  s->program.inst_len=0x1000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0xfff;
	  break;	  
	case 0x1400:
	  deviceName="16F690";
	  s->program.inst_len=0x1000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0xfff;
	  break;	  
	// JEB - added more devices based on 2.0.2 firmware
	// JEB - Note, some devices require an adapter.
	// JEB - I soldered up a simple 14 pin to 18 pin adapter.
	// JEB - See Microchip TB079 for more info.
	case 0x1140:
	  deviceName="16F716";
	  s->program.inst_len=0x0800;
	  s->program.ee_len=0;
	  s->config.save_osccal=0;
	  s->config.configmask=0x0cf;
	  break;	  
	case 0x1040:
	  deviceName="16F627A";    // Note, only A version works with PICkit
	  s->program.inst_len=0x0400;
	  s->program.ee_len=128;
	  s->config.save_osccal=0;
	  s->config.configmask=0x0ff;
	  break;	  
	case 0x1060:
	  deviceName="16F628A";    // Note, only A version works with PICkit
	  s->program.inst_len=0x0800;
	  s->program.ee_len=128;
	  s->config.save_osccal=0;
	  s->config.configmask=0x0ff;
	  break;	  
	case 0x1100:
	  deviceName="16F648A";    // Note, only A version works with PICkit
	  s->program.inst_len=0x1000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0x0ff;
	  break;	  
	case 0x1200:
	  deviceName="16F785";
	  s->program.inst_len=0x0800;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0x0fff;
	  break;	  
	case 0x0e20:
	  deviceName="16F877A";
	  s->program.inst_len=0x2000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0x2fc7;
	  break;	  
	case 0x13e0:
	  deviceName="16F913";
	  s->program.inst_len=0x1000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0x1fff;
	  break;	  
	case 0x13c0:
	  deviceName="16F914";
	  s->program.inst_len=0x1000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0x1fff;
	  break;	  
	case 0x1380:
	  deviceName="16F917";
	  s->program.inst_len=0x2000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0x1fff;
	  break;	  
	case 0x13a0:
	  deviceName="16F916";
	  s->program.inst_len=0x2000;
	  s->program.ee_len=256;
	  s->config.save_osccal=0;
	  s->config.configmask=0x1fff;
	  break;	  
	default:
	  err="No PIC or unsupported PIC found";  
	}
	if (!err)
	  fprintf(stderr,"PIC%s Rev %d found\n",deviceName,rev);
	return err;
}
/* JEB - Generate checksum.   Device is read into memory and then the checksum is 
computed.   Note this is different than using the "S" command to let the PICkit 1
Firmware calculate the checksum.   The two checksums can be compared to make sure
they match. Must be called after usb_pickit_read so
 that buffers contain the values of program memory and config word.
 Does not take into account any code protection that is turned on.*/
void usb_pickit_calc_checksum(pic14_state *s) {
	int i;
	unsigned long progchecksum, oneword;	
	pic14_word lchecksum;
	progchecksum = 0;
	lchecksum = 0;	
	for (i=0;i < s->program.inst_len; i++) {
		oneword = s->program.inst[i];
/*		printf("0x%03x=0x%04x  \n",i,oneword);*/
		progchecksum = progchecksum + oneword;
	}
	lchecksum = (progchecksum + (s->config.config & s->config.configmask)) & 0xffff; 
	s->program.instchecksum=lchecksum;

	//printf("prog length: 0c%04x  \n",s->program.inst_len);
	//printf("masked config: 0x%04x  \n",s->config.config & s->config.configmask);
	//printf("calculated checksum: 0x%04x  \n", lchecksum);
}

/* JEB - Read Checksum from device via programmer "S" function */
void usb_pickit_read_checksum(usb_pickit *d,pic14_state *s) {
	char cmd[reqLen];
	pic14_word checksum[2];	

	/* Fill in program and data legth values then send */
	sprintf(cmd,"S____V1Z");
	cmd[1]=(char)(s->program.inst_len & 0xff);
	cmd[2]=(char)(s->program.inst_len>>8);
	cmd[3]=(char)(s->program.ee_len & 0xff);
	cmd[4]=(char)(s->program.ee_len>>8);
	send_usb(d,cmd);
	recv_usb_words(d,2,checksum);
	send_usb(d,"pV1ZZZZZ");
	s->config.pgmchecksum=checksum[0];
	s->config.eechecksum=(byte)checksum[1] & 0x00ff;
 	//printf("PICkit Programmer Checksum: 0x%04x  \n", checksum[0]);
        //printf("PICkit Prgrmr Chksm EEData: 0x%02x  \n", checksum[1] & 0x00ff);
}

/** Fill out this state with the contents of the device. 
 */
void usb_pickit_read(usb_pickit *d,pic14_state *s) {
	usb_pickit_read_program(d,&s->program);
	usb_pickit_read_config(d,&s->config);
}

/** Fill out this program with the current contents of the device. 
*/
void usb_pickit_read_program(usb_pickit *d,pic14_program *p) {
	/* Read EEPROM data */
	int i,nee=0;
	send_usb(d,"PZZZZZZZ");
	while (nee<p->ee_len) {
#define eeGlobLen (8*8)
		byte eeData[eeGlobLen];
		send_usb(d,"rrrrrrrr");
		recv_usb(d,eeGlobLen,eeData);
		for (i=0;i<eeGlobLen;i++) 
			p->ee[nee++]=eeData[i];
	}
	send_usb(d,"pZZZZZZZ"); 
	
	/* Read instruction data */
	send_usb(d,"PZZZZZZZ"); 
	recv_usb_words(d,p->inst_len,p->inst);
	send_usb(d,"pV1ZZZZZ");
}

/** Send this program to the device.
 */
void usb_pickit_write_program(usb_pickit *d,pic14_program *p) {
	unsigned int i;
		
	/* Write out the EEPROM data */
	send_usb(d,"PZZZZZZZ");
	
	fprintf(stderr,"Writing %d eeprom words\n",p->max_ee);
	for (i=0;i<p->max_ee;i++) {
		char cmd[reqLen];
		sprintf(cmd,"D_ZZZZZZ");
		cmd[1]=(char)(p->ee[i]);
		send_usb(d,cmd);
	}
	send_usb(d,"pZZZZZZZ");
	
	/* Write out the program data */
	send_usb(d,"PZZZZZZZ");
	fprintf(stderr,"Writing %d program words\n",p->max_prog);
	send_usb_words(d,p->max_prog,p->inst);
	send_usb(d,"pV1ZZZZZ");
}

/** Fill out this configuration with the contents of the device. 
 */
void usb_pickit_read_config(usb_pickit *d,pic14_config *c) {
	/* Read OSCCAL from 0x03ff */
	send_usb(d,"V0V1PI\xff\x03");
	recv_usb_words(d,1,&c->osccal);
	/* Read config. id's from 0x2000 */
	send_usb(d,"pV0V1PCZ");
	recv_usb_words(d,pic14_id_len,c->id);
	/* Read config. word from 0x2007 */
	send_usb(d,"pPCI\x07\x00ZZ");
	recv_usb_words(d,1,&c->config);
	send_usb(d,"pV1ZZZZZ");
}

/** Write the configuration (osccal, id, and config word) 
    to the device.  Writes all the bits in the config. word.
 */
void usb_pickit_write_config(usb_pickit *d,pic14_config *c) {
	/* Write OSCCAL to 0x03ff */
	send_usb(d,"V0V1PI\xff\x03");
	if (c->save_osccal)
	  send_usb_word(d,c->osccal);
	/* Write config. id's to 0x2000 */
	send_usb(d,"pV0V1PCZ");
	send_usb_words(d,pic14_id_len,c->id);
	/* Write config. word to 0x2007 */
	send_usb(d,"pPCI\x07\x00ZZ");
	send_usb_word(d,c->config);
	send_usb(d,"pV1ZZZZZ");
}

/** Write this state.  If keepOld (RECOMMENDED), will 
   preserve old osccal and BG bits. */
void usb_pickit_write(usb_pickit *d,pic14_state *s,int keepOld) {
	/* Save old config bits */
        int keepEeprom;
	pic14_config oldconfig;
	pic14_word pgmchecksum;
	if (keepOld) usb_pickit_read_config(d,&oldconfig);

	if (s->program.max_ee==0) 	// JEB - Fixed Bug, should be == not =
	  keepEeprom=1;
	else
	  keepEeprom=0;
	  
	usb_pickit_reset(d,keepEeprom);
	
	/* Write new program */
	usb_pickit_write_program(d,&s->program);
	/* JEB - Calc Checksum, and Get Checksum from PICkit, compare and then announce
	result.   This is the same way as it is done in the software that comes with the
	PICKit.   More reliable to verify after the write, same functionality as Windows version */
	usb_pickit_calc_checksum(s);
        printf("Calculated Checksum from .hex file: 0x%04x  \n", s->program.instchecksum);
	usb_pickit_read_checksum(d,s);
	pgmchecksum = (s->config.pgmchecksum + (s->config.config & s->config.configmask)) & 0xffff; 
        printf("              Checksum from PICKit: 0x%04x  \n", pgmchecksum);
	if (s->program.instchecksum == pgmchecksum)
                printf("Checksums are equal.  Device Programming Successful.\n");
        else
                printf("!Checksum verify failed.  Error in Programming.\n");

	/* JEB - moved config word program to after program memory because othererwise, 
	would set the code protect bits before the write of program and data memory.
	which would not allow the write of program or data memory, works fine with 2.0.2 firmware*/
	if (keepOld) /* Normal case: merge new and old configs */
		usb_pickit_merge_config(d,&oldconfig,&s->config);
	else /* DANGEROUS: blast in new config */
		usb_pickit_write_config(d,&s->config);
}

/** JEB - Erase Device.   Checks to see if save_osccal is set, and if so
preserves osccal and BG bits.  */
void usb_pickit_erase(usb_pickit *d,pic14_state *s) {
        pic14_config oldconfig;
	pic14_word bgbits;
        /* If OscCal device, save old config bits */
        if (s->config.save_osccal) usb_pickit_read_config(d,&oldconfig);
	/* Wipe device */
        usb_pickit_reset(d,0);
        /* If needed, write in saved config bits */
        if (s->config.save_osccal) {
		/* Write OSCCAL to 0x03ff */
        	send_usb(d,"V0V1PI\xff\x03");
          	send_usb_word(d,oldconfig.osccal);
        	/* Restore BG bits and then Write config. word to 0x2007 */
		bgbits = (0x3000 & oldconfig.config) | s->config.configmask;
        	send_usb(d,"pPCI\x07\x00ZZ");
        	send_usb_word(d,bgbits);
        	send_usb(d,"pV1ZZZZZ");
	}
        printf("Device erased.\n");
}

/** Do a hard chip reset. You *must* preserve config first. */
void usb_pickit_reset(usb_pickit *d,int keepEeprom) {
	/* Blank out the device completely */
  if (keepEeprom) {
    send_usb(d,"PCEpZZZZ");
  } else {
    send_usb(d,"PCEepZZZ");
  }
}

void usb_pickit_merge_config(usb_pickit *d,
	pic14_config *oldconfig, pic14_config *newconfig)
{
	int i;
	pic14_config merged=*newconfig;
	merged.osccal=oldconfig->osccal;
#define BG_MASK 0x3000 /* mask to extract bandgap bits */
        merged.config=(oldconfig->config&BG_MASK)+(newconfig->config&~BG_MASK);
	usb_pickit_write_config(d,&merged);
}

/** JEB - Set bandgap bits.   For 629,675,630 and 676 only.   */
void usb_pickit_bandgap(usb_pickit *d,pic14_state *s,const char *bgarg) {
        pic14_config oldconfig;
        pic14_word configword, bg;
	bg = (pic14_word) atoi(bgarg);
	if ( bg > 3) printUsage("bandgap must be between 0 and 3");
        /* If 629,675,630 or 676, only devices to use osccal/bg  */
	if (s->config.save_osccal) {
		/* Get old OscCal to preserve*/
		usb_pickit_read_config(d,&oldconfig);
        	/* Wipe device */
        	usb_pickit_reset(d,0);
                /* Write OSCCAL to 0x03ff */
        	send_usb(d,"V0V1PI\xff\x03");
                send_usb_word(d,oldconfig.osccal);
                /* Insert BG bits and then Write config. word to 0x2007 */
                configword = bg<<12 | s->config.configmask;
                send_usb(d,"pPCI\x07\x00ZZ");
                send_usb_word(d,configword);
                send_usb(d,"pV1ZZZZZ");
        	printf("Device erased.\n");
		printf("OscCal 0x%04x reprogrammed.\n",oldconfig.osccal);
		printf("Bandgap 0x%1x programmed.\n",bg);
        } else 
		printf("Only PIC 629,675,630,676 support Bandgap Bits.\n");
}

/** JEB - Regenerate OscCal using the PICkit 2.5kHz Oscillator and the autocal.hex file that
comes with the PICkit.    In general, one should try not to lose the OscCal in the first place
but this is a reasonable backup.   If you need to get really accurate onboard Oscillator function
then you need to write a program that twiddles a bit, accounts for the instruction cycle timing
and then use an oscilloscope to measure the output.  You can also do this with the by selecting
the internal Osc with clkout option and watch that pin with your scope.   This is the only way
to get a really accurate IntOsc and is still probably varies a bit with temperature.   
This function is for use with the 629,675,630 and 676 only. */
void usb_pickit_osccal_regen(usb_pickit *d,pic14_state *s) {
	pic14_word configword, osccal;
	byte eedata[8];
	/* If 629,675,630 or 676, only devices to use osccal/bg  */
        if (s->config.save_osccal) {
		/* Read config. word from 0x2007, and power off device*/
		send_usb(d,"pPCI\x07\x00ZZ");
        	recv_usb_words(d,1,&configword);
       		send_usb(d,"pV1ZZZZZ");
		/* Start PICkit 2.5kHz Osc and then Powerup Device.
		delay and then Powerdown Device*/
		usb_pickit_osc_on(d);
		sleep(1);	
		usb_pickit_off(d);
		/* Get the calibrated value stored in the last location of Data Memory */
        	send_usb(d,"PI\x78\x00rpZZ");
        	recv_usb(d,8,eedata);
                /* Wipe device */
                usb_pickit_reset(d,0);
                /* Write OSCCAL to 0x03ff */
		osccal = eedata[7];;
		osccal = osccal | 0x3400;  // Or with 0x34 to create retlw value
		send_usb(d,"pV1ZZZZZ");
                send_usb(d,"PI\xff\x03ZZZZ");
                send_usb_word(d,osccal);  
                /* Write config. word to 0x2007 */
                configword = (0x3000 & configword) | s->config.configmask;
                send_usb(d,"pPCI\x07\x00ZZ");
                send_usb_word(d,configword);  
                send_usb(d,"pV1ZZZZZ"); 
                printf("Device erased.\n");
                printf("OscCal 0x%04x regenerated and programmed.\n",osccal);
                printf("Config Word & Bandgap 0x%04x restored.\n",configword);
        } else
                printf("Only PIC 629,675,630,676 support OscCal Regeneration.\n");
}
 
/* JEB - Print the Memory map of the device.    First the program memory to the length specified
in the get_device routine, and then the eeprom data memory.  This is a convenient way
to visually inspect the device if needed.  Gives most of the functionality of the GUI
based programs and is a good substitute until I have time to write a Cocoa GUI interface.*/
void usb_pickit_memory_map(usb_pickit *d,pic14_state *s) {
	int i,j;
	pic14_addr memlength;
	memlength = s->program.inst_len ;	
	printf("Program Memory\n");
	/* Include last byte (OscCal) for 629,675,630 and 676 devices*/
	if(s->config.save_osccal) {
		memlength = memlength + 1;
		s->program.inst[s->program.inst_len] = s->config.osccal;
	}
        for (i=0;i<memlength;i+=8) {
		printf("Addr 0x%04x:[",i);
        	for (j=0;j<8;j++) {
			printf("0x%04x",s->program.inst[i+j]);
			if (j<7) printf(" ");
		}
		printf("]\n");
	}
	printf("EE Data Memory\n");
        for (i=0;i<s->program.ee_len;i+=8) {
		printf("Addr 0x%02x:[",i);
        	for (j=0;j<8;j++) {
			printf("0x%02x",s->program.ee[i+j]);
			if (j<7) printf(" ");
		}
		printf("]\n");
	}
}

/** Print the whole configuration set (osccal, id, and config word). */
/* JEB - Here I have added code to print the device code that Mark Rages added 
support for, and to print the OSCCAL value if it exists. Also uses the functions I have
added to compute the device checksum using the PICkit 1 Firmware, which is different
than the calculated checksum.    Lastly, added code to mask off the ID bits above 7.  This is
specified by all Microship programmers */
void usb_pickit_print_config(usb_pickit *d,pic14_state *s) {
	pic14_word id[8], osccal[1],checksum[2];
	int i;
	char cmd[reqLen];

	/* Read OSCCAL from 0x3ff */
	if (s->config.save_osccal) {
		send_usb(d,"V0V1PI\xff\x03");
		recv_usb_words(d,1,osccal);
		printf("               OscCal data: [0x03ff]=0x%04x  \n", osccal[0]);
	}
	/* Now Reset and Read 8 Conf bytes at 2000h */
	send_usb(d,"pV0V1PCZ");
	recv_usb_words(d,8,id);
	send_usb(d,"pV1ZZZZZ");
	for (i=0;i<4;i++)
		printf("          Configuration ID: [0x%04x]=0x%02x  \n",
			0x2000+i,id[i] & 0x7f);
	for (i=4;i<8;i++)
		printf("        Configuration data: [0x%04x]=0x%04x  \n",
			0x2000+i,id[i] );
	printf("        Masked Config Word: 0x%04x  \n",id[7] & s->config.configmask); 
	if (s->config.save_osccal) 
		printf("       Masked Bandgap Bits: 0x%01x  \n",(id[7] & 0x3000)>>12); 
	/* Read Programmer Checksum Values  */
	sprintf(cmd,"S____V1Z");
	cmd[1]=(char)(s->program.inst_len & 0xff);
	cmd[2]=(char)(s->program.inst_len>>8);
	cmd[3]=(char)(s->program.ee_len & 0xff);
	cmd[4]=(char)(s->program.ee_len>>8);
	send_usb(d,cmd);
	recv_usb_words(d,2,checksum);
	send_usb(d,"pV1ZZZZZ");
	printf("PICkit Programmer Checksum: 0x%04x  \n", checksum[0]);
	printf("PICkit Prg+Config Checksum: 0x%04x  \n", (checksum[0] + (id[7] & s->config.configmask)) & 0xffff);
	printf("PICkit Prgrmr Chksm EEData: 0x%02x  \n", checksum[1] & 0x00ff);
}

/* JEB - This routine called from main to do all of the comparisons
for a .hex file to device verify operation. */
void usb_pickit_verify(pic14_state *file, pic14_state *dev) {
	unsigned char failed=0,testfailed=0;
        int i;
	
        for (i=0;i<dev->program.inst_len;i++) {
                //printf("File pgm[%04x]=0x%04x  Dev pgm[%04x]=0x%04x  \n",i,file->program.inst[i] ,i,dev->program.inst[i] );
                if (file->program.inst[i] != dev->program.inst[i]) {
                        testfailed = 1;
                        failed = 1;
		}
        }
        if (testfailed)
                printf("!Device verify failed.   Error in Program Memory.\n");
        else
                printf("Program Memory verified with .hex file.\n");
        if (file->program.instchecksum == dev->program.instchecksum) 
                printf("Program Memory Checksum verified with .hex file.\n");
        else {
                failed=1;
                printf("!Device verify failed.   Error in Program Memory Checksum.\n");
        } 
        //printf("File 0x%04x  \n",file->config.config & dev->config.configmask);
        //printf("Dev  0x%04x  \n",dev->config.config & dev->config.configmask);
        if ((file->config.config & dev->config.configmask) == (dev->config.config & dev->config.configmask)) 
                printf("Config Word verified with .hex file.\n");
        else {
                failed=1;
                printf("!Device verify failed.   Error in Config Word.\n");
        } 
	testfailed=0;
        for (i=0;i<4;i++) {
                //printf("File ID[%04x]=0x%02x  Dev ID[%04x]=0x%02x  \n",0x2000+i,file->config.id[i] & 0x7f,0x2000+i,dev->config.id[i] & 0x7f);
                if ((file->config.id[i] & 0x7f) != (dev->config.id[i] & 0x7f)) { 
                        testfailed = 1;
                        failed = 1;
		}
        }
        if (testfailed)
                printf("!Device verify failed.   Error in Config IDs.\n");
        else
                printf("Config IDs verified with .hex file.\n");

	testfailed=0;
        for (i=0;i<dev->program.ee_len;i++) {
                //printf("File ee[%02x]=0x%02x  Dev ee[%02x]=0x%02x  \n",i,file->program.ee[i] ,i,dev->program.ee[i] );
                if (file->program.ee[i] != dev->program.ee[i]) {
                        testfailed = 1;
                        failed = 1;
		}
        }
        if (testfailed)
                printf("!Device verify failed.   Error in EE Data Memory.\n");
        else
                printf("EE Data Memory verified with .hex file.\n");

        if (!failed) 
                printf("Device successfully verified with .hex file.\n");
        else
                printf("!Device failed to verify with .hex file.\n");
}

/* JEB - This routine called from main to do all of the comparisons
to blank check the device.   */
void usb_pickit_blank_check(pic14_state *s) {
        unsigned char failed=0,testfailed=0;
        int i;

        for (i=0;i<s->program.inst_len;i++) {
                //printf("pgm[%04x]=0x%04x  \n",i,s->program.inst[i] );
                if (s->program.inst[i] != 0x3fff) {
			testfailed = 1;
                        failed = 1;
		}
        }
        if (testfailed)
                printf("!Program Memory is not blank.\n");
        else
                printf("Program Memory is blank.\n");

        //printf("config 0x%04x  \n",s->config.config & s->config.configmask);
        if ((s->config.config & s->config.configmask) == (0x3fff & s->config.configmask)) 
                printf("Config Word is blank.\n");
        else {
                failed=1;
                printf("!Config Word is not blank.\n");
        } 

	testfailed=0;
        for (i=0;i<4;i++) {
                //printf("ID[%04x]=0x%02x  \n",0x2000+i,s->config.id[i] & 0x7f);
                if ((s->config.id[i] & 0x7f) != 0x7f) {
                        testfailed = 1;
                        failed = 1;
		}
        }
        if (testfailed)
                printf("!Config IDs are not blank.\n");
        else
                printf("Config IDs are blank.\n");

	testfailed=0;
        for (i=0;i<s->program.ee_len;i++) {
                //printf("ee[%02x]=0x%02x  \n",i,s->program.ee[i]);
                if (s->program.ee[i] != 0xff) {
                        testfailed = 1;
                        failed = 1;
		}
        }
        if (testfailed)
                printf("!EE Data Memory is not blank.\n");
        else
                printf("EE Data Memory is blank.\n");

        if (!failed) 
                printf("Device is blank.\n");
        else
                printf("!Device is not blank.\n");
}
